param(
    [Parameter(Mandatory = $true)]
    [string]$Container
)

$ErrorActionPreference = 'Stop'
$databases = @('identity', 'transport', 'booking', 'payment', 'notification', 'reporting')
$checksums = @{}
foreach ($line in Get-Content -LiteralPath (Join-Path $PSScriptRoot 'SHA256SUMS')) {
    if ($line -notmatch '^([a-f0-9]{64})  ([a-z]+\.dump)$') {
        throw "Invalid checksum entry: $line"
    }
    $checksums[$Matches[2]] = $Matches[1]
}

function Invoke-Docker {
    & docker @args
    if ($LASTEXITCODE -ne 0) { throw "Docker command failed (exit $LASTEXITCODE): $($args[0])" }
}

$checkSql = @'
SELECT count(*) FROM pg_namespace
WHERE nspname !~ '^pg_' AND nspname NOT IN ('public', 'information_schema')
UNION ALL
SELECT count(*) FROM pg_class WHERE relnamespace = 'public'::regnamespace
UNION ALL
SELECT count(*) FROM pg_extension WHERE extname <> 'plpgsql';
'@

foreach ($database in $databases) {
    $name = "$database.dump"
    $path = Join-Path $PSScriptRoot $name
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash
    if ($actual -ne $checksums[$name]) { throw "Checksum mismatch for $name" }
}

foreach ($database in $databases) {
    $objects = @(Invoke-Docker exec $Container psql -X -U platform -d $database -v ON_ERROR_STOP=1 -Atc $checkSql)
    if ($objects.Count -ne 3 -or @($objects | Where-Object { $_ -ne '0' }).Count -ne 0) {
        throw "Database '$database' is not empty. Use a fresh local PostgreSQL volume."
    }
}

$stage = "/tmp/pbl6-restore-$([Guid]::NewGuid().ToString('N'))"
Invoke-Docker exec $Container mkdir -m 700 $stage
try {
    foreach ($database in $databases) {
        $file = "$database.dump"
        Invoke-Docker cp (Join-Path $PSScriptRoot $file) "${Container}:$stage/$file"
        Invoke-Docker exec $Container pg_restore -U platform -d $database --no-owner --no-acl --exit-on-error --single-transaction "$stage/$file"
        Write-Host "Restored $database"
    }
}
finally {
    foreach ($database in $databases) {
        Invoke-Docker exec $Container rm -f "$stage/$database.dump"
    }
    Invoke-Docker exec $Container rmdir $stage
}

